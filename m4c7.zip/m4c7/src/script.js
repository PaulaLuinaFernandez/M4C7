function operaciones (num1, num2, num3, num4) {
  
  var sum1 = num1 + num2;
  var sum2 = num3 + num4;
  var resultado = sum1 * sum2;
  
  if (resultado > 50) {
    console.log('¡El número es mayor que 50!');
  } else if (resultado < 50) {
    console.log('¡El número es menor que 50!');
  } else {
    console.log('¡El número es igual que 50!');
  }
}

operaciones (1, 2, 3, 4);
operaciones (10, 20, 30, 40);
operaciones (10, 15, 1, 1);
